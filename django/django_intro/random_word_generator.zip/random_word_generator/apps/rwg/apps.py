from django.apps import AppConfig


class RwgConfig(AppConfig):
    name = 'rwg'
